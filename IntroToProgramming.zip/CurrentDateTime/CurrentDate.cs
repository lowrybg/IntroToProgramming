﻿/*Problem 14.* Current Date and Time

    Create a console application that prints the current date and time. Find out how in Internet.
*/
using System;

class CurrentDate
{
    static void Main()
    {
        DateTime current = DateTime.Now;
        Console.WriteLine(current);
    }
}
